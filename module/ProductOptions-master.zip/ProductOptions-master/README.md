ProductOptions
==============

Magento module - Get configurable product options in product list (category view)  http://www.atwix.com/magento/configurable-product-options-category-view
