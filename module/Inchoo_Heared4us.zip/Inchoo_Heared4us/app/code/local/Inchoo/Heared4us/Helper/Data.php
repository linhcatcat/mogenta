<?php
class Inchoo_Heared4us_Helper_Data extends Mage_Checkout_Helper_Data
{
}