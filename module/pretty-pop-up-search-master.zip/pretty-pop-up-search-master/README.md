#Search Popup for Magento CE (Community Edition)

This extension replaces old magento search popup to the new one that looks much better

**Installation:**
Just move files to Magento root dir
