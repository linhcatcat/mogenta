<?php

class Inchoo_Adminblock_Block_Adminhtml_Adminblock extends Mage_Core_Block_Template{
    
    //here we can put some logic if we want to call it in our adminblock.phtml
}