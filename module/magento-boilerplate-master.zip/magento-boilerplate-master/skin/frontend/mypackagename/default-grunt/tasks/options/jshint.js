module.exports = {
    beforeconcat: ['js/*.js']
}