# [![Inchoo](http://inchoo.net/wp-content/themes/inchoo4/images/logo.svg)](http://inchoo.net) [Auto Gender](http://inchoo.net/ecommerce/magento/magento-automatic-gender-recognition-plugin/)

Extension is based on Rapleaf personalization API. Rapleaf provides demographic and lifestyle data (age, gender, marital status, income, etc.) on personal consumer email addresses (but not for business emails). They partner with dozens of large (and small) data companies to aggregate data and tie it to email addresses.
You can create a free Rapleaf account to get an API key for 1000 free age and gender queries.
