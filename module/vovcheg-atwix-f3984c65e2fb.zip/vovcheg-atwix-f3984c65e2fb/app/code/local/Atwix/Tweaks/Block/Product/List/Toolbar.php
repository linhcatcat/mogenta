<?php
class Atwix_Tweaks_Block_Product_List_Toolbar extends Mage_Catalog_Block_Product_List_Toolbar
{
    protected $_direction = 'asc';
}
