<?php

class Atwix_Exgrid_Block_Adminhtml_Template_Grid_Renderer_Country extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Action
{
    public function render(Varien_Object $row)
    {
        return $this->_getValue($row);
    }

    public function _getValue(Varien_Object $row)
    {

        $val = $row->getData($this->getColumn()->getIndex());

        return Mage::app()->getLocale()->getCountryTranslation($val);
    }
}