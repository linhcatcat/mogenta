<?php

class Ajzele_ModelValidationExample_Model_Account extends Mage_Core_Model_Abstract
{
	//Allowed account types
	private $_accountTypes = array(
		'basic',
		'admin',
	);
	
    protected function _construct()
    {
        $this->_init('mve/account');
    }	
    
    public function validate()
    {
        $errors = array();
        $helper = Mage::helper('mve');
        
        if(!in_array($this->getAccountType(), $this->_accountTypes)) {
			$errors[] = $helper->__('Invalid account type. Please use one of these: %s.', implode(', ', $this->_accountTypes));
        }
        
        if (!Zend_Validate::is($this->getUserId(), 'Int')) {
            $errors[] = $helper->__('Please use integer value for "user_id" field.');
        }

        if (empty($errors) || $this->getShouldIgnoreValidation()) {
            return true;
        }
        return $errors;
    }     
}