<?php

class Ajzele_ModelValidationExample_Model_User extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('mve/user');
    }	
    
    public function validate()
    {
        $errors = array();
        $helper = Mage::helper('mve');
        
        if (!Zend_Validate::is($this->getFirstname(), 'NotEmpty')) {
            $errors[] = $helper->__('Please enter the first name.');
        }

        if (!Zend_Validate::is($this->getLastname(), 'NotEmpty')) {
            $errors[] = $helper->__('Please enter the last name.');
        }

		if (!Zend_Validate::is($this->getEmail(), 'EmailAddress')) {
            $errors[] = $helper->__('Invalid email address "%s".', $this->getEmail());
        }  

		if (!Zend_Validate::is($this->getIsVip(), 'NotEmpty')) {
            $errors[] = $helper->__('Please define true/false for isVip condition.');
        }         

        if (empty($errors) || $this->getShouldIgnoreValidation()) {
            return true;
        }
        return $errors;
    }    
}