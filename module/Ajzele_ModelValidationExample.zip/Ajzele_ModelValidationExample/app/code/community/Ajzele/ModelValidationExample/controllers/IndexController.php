<?php

/**
 * 
 * Access like 
 * https://mysite.net/ajzeleModelValidationExample/
 * or
 * https://mysite.net/ajzeleModelValidationExample/index/index
 * 
 */
class Ajzele_ModelValidationExample_IndexController extends Mage_Core_Controller_Front_Action
{
	public function indexAction()
	{
			$this->loadLayout();
			$this->getLayout()->getBlock('root')->setTemplate("page/1column.phtml");
			$this->renderLayout();	
	}
	
	/**
	 * https://mysite.net/ajzeleModelValidationExample/index/testUserModelValidation
	 */
	public function testUserModelValidationAction()
	{
		$user = Mage::getModel('mve/user');
		
		//$user->setEmail('john.doe-magento.com');
		$user->setEmail('john.doe@magento.com');
		$user->setFirstname('John');
		$user->setLastname('Doe');
		//$user->setIsVip(null);
		$user->setIsVip(true);
		
		if($user->validate() === true) {
			try {
				$user->save();
			} catch (Exception $e) {
				Mage::log('Mage::getModel(mve/user)->save(): '.$e->getMessage());
			}			
		} else {
			Mage::log('Mage::getModel(mve/user)->validate(): '.print_r($user->validate(), true));
		}		
		
		echo 'testUserModelValidation...'; exit;
	}
	
	/**
	 * https://mysite.net/ajzeleModelValidationExample/index/testAccountModelValidation
	 */
	public function testAccountModelValidationAction()
	{
		$account = Mage::getModel('mve/account');
		
		//$account->setAccountType('basic2323');
		$account->setAccountType('basic');
		//$account->setUserId('asasa');
		$account->setUserId(12);
		
		if($account->validate() === true) {
			try {
				$account->save();
			} catch (Exception $e) {
				Mage::log('Mage::getModel(mve/account)->save(): '.$e->getMessage());
			}			
		} else {
			Mage::log('Mage::getModel(mve/account)->validate(): '.print_r($account->validate(), true));
		}		
		
		echo 'testAccountModelValidation...'; exit;
	}	
}