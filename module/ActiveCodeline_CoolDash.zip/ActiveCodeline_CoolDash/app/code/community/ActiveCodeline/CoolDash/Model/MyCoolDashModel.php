<?php

class ActiveCodeline_CoolDash_Model_MyCoolDashModel extends Mage_Core_Model_Abstract
{
	
}