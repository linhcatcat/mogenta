----------------------------------------------------------------------
Magento Extension - Magento Custom Menu (Web-Experiment.Info)
----------------------------------------------------------------------
Thank you for choosing the Web-Experiment Magento extension.

INSTALLATION GUIDE
Please find the installation guide here:
http://web-experiment.info/articles/cat/custom_menu/post/wp_custom_menu/

General guides page for the extension:
http://web-experiment.info/articles/cat/custom_menu/

SUPPORT
If you have any questions, please feel free to email us via our support form here:
http://web-experiment.info/support

LICENSING
This extension is licensed under a Regular Free License:
http://web-experiment.info/regular_free_license
You must not incorporate the Extension in a work which is created for Sale or Redistribute for free by you or your client.
You may use the Extension in a work which you are creating for your own purposes or for your client who has asked you to create it.



