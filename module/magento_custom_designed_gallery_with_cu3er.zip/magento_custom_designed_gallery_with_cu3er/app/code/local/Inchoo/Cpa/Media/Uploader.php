<?php

class Inchoo_Cpa_Media_Uploader extends Varien_File_Uploader
{
    
}
