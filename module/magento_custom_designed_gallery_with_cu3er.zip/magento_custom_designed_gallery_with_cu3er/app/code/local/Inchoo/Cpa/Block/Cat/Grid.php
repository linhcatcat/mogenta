<?php

class Inchoo_Cpa_Block_Cat_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

    public function __construct()
    {
        parent::__construct();
        $this->setId('cpaCatGrid');
       
        $this->setDefaultSort('cat_id');
        
    }

    protected function _prepareCollection()
    {
        $collection = Mage::getResourceModel('cpa/cat_collection');
        
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
    
    	$this->addColumn('cpa_id', array(
            'header'    => Mage::helper('cpa')->__('ID'),
            'width'     => 5,
            'index'     => 'cat_id'
     	))
     	->addColumn('name', array(
            'header'    => Mage::helper('cpa')->__('Name'),
            'index'     => 'cat_name'
        ));
    	
        return parent::_prepareColumns();
    }

    public function getRowUrl($row)
    {
        return $this->getUrl('*/*/edit', array('cat_id' => $row->getId()));
    }

}
