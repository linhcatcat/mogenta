<?php
class Inchoo_Cpa_Block_Cat_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
	
    public function __construct()
    {
        

    	parent::__construct();
                 
        $this->_objectId = 'cat_id';
        $this->_blockGroup = 'cpa';
        $this->_controller = 'cat';
        
        $this->_headerText = Mage::helper('cpa')->__("Edit Category '%s'", $this->htmlEscape(Mage::registry('cpa')->getCatName()));
        
        $this->_updateButton('save', 'label', Mage::helper('cpa')->__('Save Categorysss'));
        $this->_updateButton('delete', 'label', Mage::helper('cpa')->__('Delete Category'));
      	
        return parent::__construct();

    }
	
}