<?php

class Inchoo_Cpa_Block_Cat_New_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

    public function __construct()
    {
        parent::__construct();
        $this->setId('cpa_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(Mage::helper('cpa')->__('Gallery Category Management'));
    }

    protected function _beforeToHtml()
    {
        $this->addTab('info_section', array(
            'label'     => Mage::helper('cpa')->__('Gallery Category'),
            'title'     => Mage::helper('cpa')->__('Gallery Category'),
            'content'   => $this->getLayout()->createBlock('cpa/cat_new_tab_info')->toHtml(),
            'active'    => true
        ));

        return parent::_beforeToHtml();
    }

}
