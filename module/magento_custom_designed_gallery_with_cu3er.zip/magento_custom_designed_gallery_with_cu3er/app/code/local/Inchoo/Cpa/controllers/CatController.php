<?php
class Inchoo_Cpa_CatController extends Mage_Adminhtml_Controller_Action
{
    protected function _initAction()
    {
        $this->loadLayout();
        $this->_setActiveMenu('cpa/cat');
        return $this;
    }

    public function indexAction()
    {
        $this->_initAction()
             ->_addContent($this->getLayout()->createBlock('cpa/cat'))
             ->renderLayout();
    }
    
    protected function _initGallery()
    {
    	$id = $this->getRequest()->getParam('cat_id');
        $model = Mage::getModel('cpa/cat');
        $model_img = Mage::getModel('cpa/img')->getCollection();
        

        if ($id) {

            $model->load($id);

            $model_img->addFieldToFilter('category_id', array('in'=>array($id)));
            if (! $model->getCatId()) {
                Mage::getSingleton('adminhtml/session')->addError($this->__('This Category no longer exists'));
                $this->_redirect('*/*/');
                return;
            }
        }
        
        $data = Mage::getSingleton('adminhtml/session')->getCpaData(true);
        if (!empty($data)) {
            $model->setData($data);
       }
       Mage::register('cpa', $model);
       Mage::register('cpa_img', $model_img);
        

    }
    
    public function editAction()
    {
    	$this->_initGallery();
    		
    	$this->_initAction()
            ->_addContent($this->getLayout()->createBlock('cpa/cat_edit')->setData('action', $this->getUrl('*/cat/save')))
            ->_addLeft($this->getLayout()->createBlock('cpa/cat_edit_tabs'))
            ;

        $this->renderLayout();
    }
    
    public function newAction()
    {
    	$this->_initGallery();
    	$this->_initAction()
            ->_addContent($this->getLayout()->createBlock('cpa/cat_new')->setData('action', $this->getUrl('*/cat/add')))
            ->_addLeft($this->getLayout()->createBlock('cpa/cat_new_tabs'))
            ;

        $this->renderLayout();
    }
    
    
    public function saveAction()
    {
    	$id = $this->getRequest()->getParam('cat_id');
        $data = $this->getRequest()->getPost();
        $datax = $this->getRequest()->getPost('cpa_images');
        
        $datay = Zend_Json::decode($datax);
        $_photos_info = array();
        $_photos_info = Zend_Json::decode($datax);
        
    	if ($data) {
            $model = new Inchoo_Cpa_Model_Cat();

            $model->setData($data);

            
            
			$_conn = Mage::getSingleton('core/resource')->getConnection('core_write');      

            try {
            	
            	$model->save();

            	if(!empty($_photos_info)) {
            		foreach($_photos_info as $_photo_info) {
            			
            			//Do updade if we have cat id (menaing photo is already saved)
    					if(isset($_photo_info['category_id'])) {
    						
    						$data = array(
	    						"img_name" => str_replace(".tmp", "", $_photo_info['file']),
	    						"img_label" => $_photo_info['label'],
	    						"category_id" => $_photo_info['category_id'],
	    						"img_order" => $_photo_info['position'],
	    						"img_name" => str_replace(".tmp", "", $_photo_info['file'])
    						);
    						
    						$where = array("img_id = ".(int)$_photo_info['value_id']);
    						$_conn->update('inchoo_cat_images', $data, $where);

    						if(isset($_photo_info['removed']) and $_photo_info['removed'] == 1) {
	    						$_conn->delete('inchoo_cat_images', 'img_id = '.(int)$_photo_info['value_id']);

	    					}
    					}

    					else {
    						
    						$_lookup = $_conn->fetchAll("SELECT * FROM inchoo_cat_images WHERE img_name = ?", $_photo_info['file']);
    						
    						if(empty($_lookup)) {
    							
    							$_conn->insert('inchoo_cat_images', array(
    								'img_name' => str_replace(".tmp", "", $_photo_info['file']),
 	   								'img_label' => $_photo_info['label'],
    								'category_id' => (int)$id,
    								'img_order' => $_photo_info['position']
    								
    							));
    						}
							
    					}
						
            		}	
            	}
      	
				Mage::getSingleton('adminhtml/session')->addSuccess($this->__('Category was successfully saved'));
                Mage::getSingleton('adminhtml/session')->getCpaData(false);
                $this->_redirect('*/*/');
                return;
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addNotice($this->__('Category allready exists'));
                Mage::getSingleton('adminhtml/session')->setCatData($data);
                $this->_redirect('*/*/', array('cat_id' => $model->getCatId()));
                return;
            }
        }
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('cpa')->__('Unable to find Category to save'));
        $this->_redirect('*/*/');
    }  

    public function deleteAction()
    {
    	$id = $this->getRequest()->getParam('cat_id');
        if ($id) {
            try {
                $model = Mage::getModel('cpa/cat');
                $model->setId($id);
                $model->delete();
                Mage::getSingleton('adminhtml/session')->addSuccess($this->__('Category was successfully deleted'));
                $this->_redirect('*/*/');
                return;
            }catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit', array('cat_id' => $id));
                return;
            }
        }
        Mage::getSingleton('adminhtml/session')->addError($this->__('Unable to find a Category to delete'));
        $this->_redirect('*/*/');
    }
    

    public function addAction()
    {
    	$id = $this->getRequest()->getParam('cat_id');
        $data = $this->getRequest()->getPost();
        
    	if ($data) {
            $model = new Inchoo_Cpa_Model_Cat();

			$model_img = new Inchoo_Cpa_Model_Img();

			
            try {
                $model->save();
                
				Mage::getSingleton('adminhtml/session')->addSuccess($this->__('Category was successfully added'));
                Mage::getSingleton('adminhtml/session')->getCpaData(false);
                $this->_redirect('*/*/');
                return;
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                Mage::getSingleton('adminhtml/session')->setCatData($data);
                $this->_redirect('*/*/edit', array('cat_id' => $model->getCatId()));
                return;
            }
        }
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('cpa')->__('Unable to find Category to save'));
        $this->_redirect('*/*/');
    }  
    public function uploadAction()
    {
        $result = array();
        try {
            $uploader = new Varien_File_Uploader('image');
            $uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
            $uploader->setAllowRenameFiles(true);
            $uploader->setFilesDispersion(true);
            $result = $uploader->save(
                Mage::getSingleton('catalog/product_media_config')->getBaseTmpMediaPath()
            );

            $result['url'] = Mage::getSingleton('catalog/product_media_config')->getTmpMediaUrl($result['file']);
            $result['file'] = $result['file'] . '.tmp';
            $result['cookie'] = array(
                'name'     => session_name(),
                'value'    => $this->_getSession()->getSessionId(),
                'lifetime' => $this->_getSession()->getCookieLifetime(),
                'path'     => $this->_getSession()->getCookiePath(),
                'domain'   => $this->_getSession()->getCookieDomain()
            );
        } catch (Exception $e) {
            $result = array('error'=>$e->getMessage(), 'errorcode'=>$e->getCode());
        }

        $this->getResponse()->setBody(Zend_Json::encode($result));
    }
    
 	public function imageAction()
    {
        $result = array();
        try {
            $uploader = new Inchoo_Cpa_Media_Uploader('image');
            $uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
            $uploader->setAllowRenameFiles(true);
            $uploader->setFilesDispersion(true);
            $result = $uploader->save(
                Mage::getSingleton('cpa2/config')->getBaseTmpMediaPath()
            );

            $result['url'] = Mage::getSingleton('cpa2/config')->getTmpMediaUrl($result['file']);
            $result['file'] = $result['file'] . '.tmp';
            $result['cookie'] = array(
                'name'     => session_name(),
                'value'    => $this->_getSession()->getSessionId(),
                'lifetime' => $this->_getSession()->getCookieLifetime(),
                'path'     => $this->_getSession()->getCookiePath(),
                'domain'   => $this->_getSession()->getCookieDomain()
            );
        } catch (Exception $e) {
            $result = array('error'=>$e->getMessage(), 'errorcode'=>$e->getCode());
        }

        $this->getResponse()->setBody(Zend_Json::encode($result));
    }
    
}