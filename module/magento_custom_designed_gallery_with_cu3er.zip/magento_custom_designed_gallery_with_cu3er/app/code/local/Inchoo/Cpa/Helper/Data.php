<?php
class Inchoo_Cpa_Helper_Data extends Mage_Core_Helper_Abstract
{
}