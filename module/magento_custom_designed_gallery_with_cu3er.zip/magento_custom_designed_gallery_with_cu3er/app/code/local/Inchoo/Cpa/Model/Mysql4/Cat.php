<?php

class Inchoo_Cpa_Model_Mysql4_Cat extends Mage_Core_Model_Mysql4_Abstract
{

    protected function _construct()
    {
        $this->_init('cpa/cat', 'cat_id');
    }

}
