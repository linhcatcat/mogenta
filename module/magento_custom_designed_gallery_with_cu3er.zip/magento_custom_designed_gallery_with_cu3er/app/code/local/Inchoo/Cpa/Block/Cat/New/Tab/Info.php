<?php

class Inchoo_Cpa_Block_Cat_New_Tab_Info extends Mage_Adminhtml_Block_Widget_Form
{

    protected function _prepareForm()
    {
        $model = Mage::registry('cpa');
        
        $form = new Varien_Data_Form();
        
        $fieldset = $form->addFieldset('info_fieldset', array('legend'=>Mage::helper('adminhtml')->__('Inchoo Gallery Category Information')));

        if ($model->getCatId()) 
        	$fieldset->addField('cat_id', 'hidden', array('name' => 'cat_id'));
        
        $fieldset->addField('cat_name', 'text', array(
            'name'  => 'cat_name',
            'label' => Mage::helper('adminhtml')->__('Name'),
            'id'    => 'name',
            'title' => Mage::helper('adminhtml')->__('Name'),
            'required' => true,
        ));      
        
        $data = $model->getData();
        $form->setValues($data);
        $this->setForm($form);
        
        return parent::_prepareForm();
    }
}
