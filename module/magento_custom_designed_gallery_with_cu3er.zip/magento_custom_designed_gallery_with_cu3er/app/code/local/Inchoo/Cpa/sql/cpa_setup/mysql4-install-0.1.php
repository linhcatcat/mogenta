<?php

$installer = $this;

$installer->startSetup();

$installer->run("
DROP TABLE IF EXISTS {$this->getTable('inchoo_cat_images')};
CREATE TABLE {$this->getTable('inchoo_cat_images')} (
  `img_id` int(5) NOT NULL auto_increment,
  `img_name` varchar(64) default NULL,
  `img_label` varchar(64) default NULL,
  `category_id` int(5) default NULL,
  `img_order` int(5) default NULL,
  PRIMARY KEY  (`img_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

insert  into {$this->getTable('inchoo_cat_images')}(`img_id`,`img_name`,`img_label`,`category_id`,`img_order`) 
values 
(1, '/i/n/inchoo_5.jpg', '', 1, 1),
(2, '/i/n/inchoo_3.jpg', '', 1, 2),
(3, '/i/n/inchoo_2.jpg', '', 1, 3),
(4, '/i/n/inchoo_1.jpg', '', 1, 4),
(5, '/i/n/inchoo_4.jpg', '', 1, 5);

DROP TABLE IF EXISTS {$this->getTable('inchoo_categories')};
CREATE TABLE {$this->getTable('inchoo_categories')} (
  `cat_id` int(5) NOT NULL auto_increment,
  `cat_name` varchar(32) default NULL,
  PRIMARY KEY  (`cat_id`),
  UNIQUE KEY `category` (`cat_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

insert  into {$this->getTable('inchoo_categories')}(`cat_id`,`cat_name`) values (1,'inchoo');

");

$installer->endSetup();