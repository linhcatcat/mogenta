<?php

class Inchoo_Cpa_Block_Cat extends Mage_Adminhtml_Block_Widget_Grid_Container
{

    public function __construct()
    {
    	$this->_blockGroup = 'cpa';
        $this->_controller = 'cat';
        
        $this->_headerText = Mage::helper('cpa')->__('Categories');
        $this->_addButtonLabel = Mage::helper('cpa')->__('Add New Category');
        parent::__construct();
    }

}
