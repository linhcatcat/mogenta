<?php

class Inchoo_Cpa_Media_Config extends Mage_Catalog_Model_Product_Media_Config
{

    public function getBaseMediaPath()
    {
        return Mage::getBaseDir('media') . DS . 'cpa_art';
    }

    public function getBaseMediaUrl()
    {
        return Mage::getBaseUrl('media') . 'cpa_art';
    }

    public function getBaseTmpMediaPath()
    {
        return Mage::getBaseDir('media') . DS . 'cpa_art';
    }

    public function getBaseTmpMediaUrl()
    {
        return Mage::getBaseUrl('media') . 'cpa_art';
    }
     
}