<?php
class Incho_FrontGall_Model_Gallery extends Mage_Catalog_Model_Product
{

}
