<?php

class Inchoo_GallFront_IndexController extends Mage_Core_Controller_Front_Action
{

   	
   	protected function _initGallery()
    {
    	$id = $this->getRequest()->getParam('cat_id');
        $model = Mage::getModel('cpa/cat');
        $model_img = Mage::getModel('cpa/img')->getCollection();
        

        if ($id) {

            $model->load($id);

            $model_img->addFieldToFilter('category_id', array('in'=>array($id)));
            if (! $model->getCatId()) {
                Mage::getSingleton('adminhtml/session')->addError($this->__('This Category no longer exists'));
                $this->_redirect('*/*/');
                return;
            }
        }
        
        $data = Mage::getSingleton('adminhtml/session')->getCpaData(true);
        if (!empty($data)) {
            $model->setData($data);
       }
       Mage::register('cpa', $model);
       Mage::register('cpa_img', $model_img);

    }

    
    public function indexAction()
    {
        // action body
       	$this->_initGallery();
       
       	$this->loadLayout();   
	
		$block = $this->getLayout()->createBlock(
				'Mage_Core_Block_Template',
				'',
				array(
					'template' => 'gallery/demo.phtml'
					)
				);
		
		$this->getLayout()->getBlock('content')->append($block);
				
		$this->_initLayoutMessages('core/session');
		
		$this->renderLayout();

    }

}