<?php

class Inchoo_GallFront_Cu3erController extends Mage_Core_Controller_Front_Action
{

    public function indexAction()
    {
       	$this->loadLayout();   
	
		$block = $this->getLayout()->createBlock(
				'Mage_Core_Block_Template',
				'',
				array(
					'template' => 'gallery/cu3er.phtml'
					)
				);
		
		$this->getLayout()->getBlock('content')->append($block);
				
		$this->renderLayout();
    }
    
}