<?php

class Inchoo_GallFront_XmlController extends Mage_Core_Controller_Front_Action
{

	protected $_g;
   	
   	protected function _initGallery()
    {
    	$id = $this->getRequest()->getParam('cat_id');
        $model = Mage::getModel('cpa/cat');
        $model_img = Mage::getModel('cpa/img')->getCollection();

        if ($id) {

            $model->load($id);

            $model_img->addFieldToFilter('category_id', array('in'=>array($id)));
            if (! $model->getCatId()) {
                Mage::getSingleton('adminhtml/session')->addError($this->__('This Category no longer exists'));
                $this->_redirect('*/*/');
                return;
            }
        }
        
        $data = Mage::getSingleton('adminhtml/session')->getCpaData(true);
        if (!empty($data)) {
            $model->setData($data);
       }
       Mage::register('cpa', $model);
       Mage::register('cpa_img', $model_img);

       $this->_g = Mage::registry('cpa_img')->getData();
    }

    
    public function indexAction()
    {
    	
    	/*
    	 * start cu3er sample xml
    	 * 
    	 * <?xml version="1.0" encoding="utf-8" ?>
				<cu3er>
					<settings>
				    	<prev_button>
							<defaults round_corners="5,5,5,5"/>
							<tweenOver tint="0xFFFFFF" scaleX="1.1" scaleY="1.1"/>
							<tweenOut tint="0x000000" />
						</prev_button>
				    	<prev_symbol>
							<tweenOver tint="0x000000" />			
						</prev_symbol>
				    	<next_button>
							<defaults round_corners="5,5,5,5"/>			
							<tweenOver tint="0xFFFFFF"  scaleX="1.1" scaleY="1.1"/>
							<tweenOut tint="0x000000" />
						</next_button>
				    	<next_symbol>
							<tweenOver tint="0x000000" />
						</next_symbol>	
					</settings>    
				
					<slides>
				        <slide>
				            <url>images/slide_1.jpg</url>
				        </slide>
						<!-- changing transition between first & second slide -->
				        <transition num="3" slicing="vertical" direction="down"/>
				        <slide>
				       		<url>images/slide_2.jpg</url>
				        </slide>		
						<!-- changing transition between second & third slide -->
				        <transition num="4" direction="right" shader="flat" />
						<slide>
				            <url>images/slide_3.jpg</url>
				        </slide>
				        <!-- transitions properties defined in transitions template -->
						<slide>
				       		<url>images/slide_4.jpg</url>
				        </slide>
						<transition num="6" slicing="vertical" direction="up" shader="flat" delay="0.05" z_multiplier="4" />
				        <slide>
				       		<url>images/slide_5.jpg</url>
				        </slide>
					</slides>
				</cu3er>
    	 * 
    	 * end cu3er sample xml
    	 */
    	
    	$this->_initGallery();
    	
    	$imgPath = '/media/cpa_art';
    	
		$xml = new DOMDocument( "1.0", "utf-8" );
		
		$xml_cu3er = $xml->createElement( "cu3er" );
		
		
		$xml_settings = $xml->createElement( "settings" );
		$xml_slides = $xml->createElement( "slides" );
		
		
		$xml_prev_button = $xml->createElement( "prev_button" );
		$xml_prev_symbol = $xml->createElement( "prev_symbol" );
		$xml_next_button = $xml->createElement( "next_button" );
		$xml_next_symbol = $xml->createElement( "next_symbol" );
		
		$xml_settings->appendChild( $xml_prev_button );
		$xml_settings->appendChild( $xml_prev_symbol );
		$xml_settings->appendChild( $xml_next_button );
		$xml_settings->appendChild( $xml_next_symbol );
		
		
		foreach($this->_g as $img)
		{
			/*
			 * start sample transition tag: 
			 * <transition num="3" slicing="vertical" direction="down"/>
			 */
					$xml_transition = $xml->createElement( "transition");
		
		
					$xml_num = $xml->createAttribute("num");
					$xml_slicing = $xml->createAttribute("slicing");
					$xml_direction = $xml->createAttribute("direction");
					
					$xml_transition->appendChild($xml_num);
					$xml_transition->appendChild($xml_slicing);
					$xml_transition->appendChild($xml_direction);
			
					$xml_num_value = $xml->createTextNode($img["img_order"]);
					$xml_num->appendChild($xml_num_value);
					
					$xml_slicing_value = $xml->createTextNode("vertical");
					$xml_slicing->appendChild($xml_slicing_value);
					
					$xml_direction_value = $xml->createTextNode("down");
					$xml_direction->appendChild($xml_direction_value);

			/*
			 * end sample transition tag: 
			 * <transition num="3" slicing="vertical" direction="down"/>
			 */		
			
			$xml_slide = $xml->createElement( "slide" );		
			$xml_url = $xml->createElement( "url", $imgPath.$img["img_name"]);	
			$xml_slide->appendChild( $xml_url );
			$xml_slides->appendChild( $xml_slide );
			$xml_slides->appendChild( $xml_transition );
		}
		
		
		
		$xml_cu3er->appendChild( $xml_settings );
		$xml_cu3er->appendChild( $xml_slides );
		
		$xml->appendChild( $xml_cu3er );
		
		// Parse the XML.
		print $xml->saveXML();
    }

}