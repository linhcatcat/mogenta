Inchoo_USDisableRegions
=======================
This extension allows you to select which regions are available to be used for
customer address creation.

It works only for US.

Extension is tested only on Magento ver. 1.7.0.2

Keep in mind that this extension is created for purposes of blog article at inchoo.net and as such can
only be used as proof of concept. If you find it helpful in order to learn Magento, that is great, but be careful
if you plan to use it in production environment.