<?php

class Inchoo_CoffeeFreak_Helper_Data extends Mage_Core_Helper_Data
{
 
}