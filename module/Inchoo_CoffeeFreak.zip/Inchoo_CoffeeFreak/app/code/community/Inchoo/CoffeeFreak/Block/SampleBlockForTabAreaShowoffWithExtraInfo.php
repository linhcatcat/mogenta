<?php

class Inchoo_CoffeeFreak_Block_SampleBlockForTabAreaShowoffWithExtraInfo extends Mage_Adminhtml_Block_Template
{
	
    public function __construct()
    {   	
        parent::__construct();
        $this->setTemplate('inchoo/sample_for_tab_container.phtml');       
    }	 
}