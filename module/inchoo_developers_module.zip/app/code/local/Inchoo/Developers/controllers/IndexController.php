<?php

/**
 * Magento Commercial Edition
 *
 * @category    Inchoo
 * @package     Inchoo_Developers
 * @author		Vedran Subotic	-	vedran@inchoo.net
 */

class Inchoo_Developers_IndexController extends Mage_Core_Controller_Front_Action 
{
	
	/*
	 * 
	 * 
	 * */
	public function indexAction()
	{
		$this->_title($this->__('Inchoo Developers'))->_title($this->__('Frontend Controller'));
		$this->loadLayout();
        $this->_initLayoutMessages('adminhtml/session');
        $this->renderLayout();
        
        //$this->_redirect('/');
        Zend_Debug::dump($this->getLayout()->getUpdate()->getHandles());
	}
	
	public function testAction()
	{
        //$this->_redirect('/');
	}

}