<?php
/**
 * Magento Commercial Edition
 *
 * @category    Inchoo
 * @package     Inchoo_Developers
 * @author		Vedran Subotic	-	vedran@inchoo.net
 */


class Inchoo_Developers_Adminhtml_Switch_IndexController extends Mage_Adminhtml_Controller_Action
{

	public function indexAction()
	{
		$this->_title($this->__('System'))->_title($this->__('Inchoo Developers'));
        
		$this->loadLayout();
        $this->_initLayoutMessages('adminhtml/session');
		
		$this->_setActiveMenu('inchoo_developers');

        /*
         * next two lines have same functionality
         * they call same block
         */

        $this->_addContent($this->getLayout()->createBlock('inchoo_developers/adminhtml_switch_index'));
        //$this->_addContent($this->getLayout()->createBlock('inchoo_developers_admin/switch_index'));
        
        $this->renderLayout();
        

	}
	
}
