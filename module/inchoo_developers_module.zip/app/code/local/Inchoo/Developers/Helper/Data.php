<?php
/**
 * Magento Commercial Edition
 *
 * @category    Inchoo
 * @package     Inchoo_Developers
 * @author		Vedran Subotic	-	vedran@inchoo.net
 */

/**
 * Inchoo_Developers data helper
 */
class Inchoo_Developers_Helper_Data extends Mage_Core_Helper_Abstract
{

}
