<?php
/**
 * Magento Commercial Edition
 *
 * @category    Inchoo
 * @package     Inchoo_Developers
 * @author		Vedran Subotic	-	vedran@inchoo.net
 */

class Inchoo_Developers_Block_Adminhtml_Switch_Index extends Mage_Adminhtml_Block_Template
{
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('developers/switch.phtml');
    }

    protected function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
    
	public function getHandleUpdates()
	{
		Zend_Debug::dump($this->getLayout()->getUpdate()->getHandles());
	}

}
	