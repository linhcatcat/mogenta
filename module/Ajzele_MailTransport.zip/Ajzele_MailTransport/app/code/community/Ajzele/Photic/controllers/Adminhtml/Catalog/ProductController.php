<?php
/**
 * Ajzele
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE_AFL.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 *
 * @category   Ajzele
 * @package    Ajzele_Photic
 * @copyright  Copyright (c) Branko Ajzele (http://ajzele.net)
 * @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

include getcwd().'/app/code/core/Mage/Adminhtml/controllers/Catalog/ProductController.php';

class Ajzele_Photic_Adminhtml_Catalog_ProductController extends Mage_Adminhtml_Catalog_ProductController
{
	//Blank, no implementation...
}
