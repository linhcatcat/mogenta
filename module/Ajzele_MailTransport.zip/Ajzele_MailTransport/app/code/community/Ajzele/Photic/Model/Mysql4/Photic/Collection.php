<?php
class Ajzele_Photic_Model_Mysql4_Photic_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{ 
    public function __construct()
    {
		$this->_init('photic/photic');
    }
}