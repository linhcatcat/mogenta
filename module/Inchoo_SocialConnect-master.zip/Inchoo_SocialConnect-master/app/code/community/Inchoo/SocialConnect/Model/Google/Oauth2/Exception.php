<?php

class Inchoo_SocialConnect_Model_Google_OAuth2_Exception extends Exception
{}