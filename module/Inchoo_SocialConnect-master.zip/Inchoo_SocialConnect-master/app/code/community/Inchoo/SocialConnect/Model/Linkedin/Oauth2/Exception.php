<?php

class Inchoo_SocialConnect_Model_Linkedin_Oauth2_Exception extends Exception
{
    
}