<?php

class Inchoo_SocialConnect_Model_Twitter_OAuth_Exception extends Exception
{}