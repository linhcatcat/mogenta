<?php

class Inchoo_SocialConnect_Model_Facebook_OAuth2_Exception extends Exception
{}